document.addEventListener('DOMContentLoaded', () => {
    // Carrusel de formación
    const carousel = document.querySelector('.formacion__carrusel');
    const items = document.querySelectorAll('.formacion__item');
    const prevBtn = document.querySelector('.formacion__prev');
    const nextBtn = document.querySelector('.formacion__next');
    let currentIndex = 0;

    function moveCarousel(direction) {
        currentIndex = (currentIndex + direction + items.length) % items.length;
        updateCarousel();
    }

    function updateCarousel() {
        const itemWidth = items[0].offsetWidth;
        carousel.style.transform = `translateX(-${currentIndex * itemWidth}px)`;
    }

    prevBtn.addEventListener('click', () => moveCarousel(-1));
    nextBtn.addEventListener('click', () => moveCarousel(1));

    // Navegación suave
    function scrollToSection(sectionId) {
        document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
    }

    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', (e) => {
            const sectionId = e.target.getAttribute('onclick').match(/'([^']+)'/)[1];
            scrollToSection(sectionId);
        });
    });

    // Búsqueda en el portafolio
    document.getElementById('search-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const searchTerm = this.value.toLowerCase();
            const sections = ['sobre-mi', 'habilidades', 'aficiones', 'formacion', 'experiencia', 'contacto'];
            for (let section of sections) {
                if (section.includes(searchTerm)) {
                    scrollToSection(section);
                    break;
                }
            }
            this.value = '';
        }
    });

    // Modal de imágenes
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImage');
    const closeBtn = document.querySelector('.modal__close');

    document.querySelectorAll('.experiencia__imagen').forEach(img => {
        img.addEventListener('click', function() {
            modal.style.display = 'block';
            modalImg.src = this.src;
        });
    });

    closeBtn.addEventListener('click', () => modal.style.display = 'none');

    window.addEventListener('click', (event) => {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });

    // Efecto de movimiento en la foto de perfil
    const photo = document.querySelector('.presentacion__foto');
    
    document.addEventListener('mousemove', (e) => {
        const { clientX, clientY } = e;
        const { innerWidth, innerHeight } = window;
        
        const moveX = (clientX / innerWidth - 0.5) * 20;
        const moveY = (clientY / innerHeight - 0.5) * 20;
        
        photo.style.transform = `translate(${moveX}px, ${moveY}px)`;
    });

    // Inicializar el carrusel
    updateCarousel();
});
